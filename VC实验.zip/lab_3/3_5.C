#include<stdio.h>
int main()
{
int x,y,z,i;
float m;
printf("Enter the money: ");
scanf("%f",&m);
i=0;
for(x=1;x<=m/1;x++)
for(y=1;y<=m/2;y++)
for(z=1;z<=m/5;z++)
{
if(x+2*y+5*z==m)
{
printf("one cent:%d	,two cents:%d	,five cents:%d	\n",x,y,z);
i++;
}
}
printf("The total methods are %d \n",i);
getch();
return 0;
}