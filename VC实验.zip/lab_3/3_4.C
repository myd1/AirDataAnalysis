#include<stdio.h>
#include<math.h>
int main()
{
int i,n;
float a,f;
printf("Enter a number: ");
scanf("%d",&n);
f=0;
for(i=1;i<=n;i++)
{
a=pow(-1,i-1)/(3*i-2);
f=f+a;
}
printf("the sum is %.2f\n",f);
getch();
return 0;
}