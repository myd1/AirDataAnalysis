#include<stdio.h>
int main()
{
int a,b;
a=500,b=0;
while(b<=50)
{
(a%3==2&&a%5==2&&a%7==2)?
printf("%d	",a),a++,b++:a++;
}
printf("\n");
getch();
return 0;
}