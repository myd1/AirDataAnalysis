#include<stdio.h>
#define N 10
void input(int *) ;
int search(int *,int );
int main()
{
int a[N];
int k;
int p;
  printf("please inpur the number :\n");
 input(a);
  printf("plese input a number to be find:\n");
	  scanf("%d",&k);
 p = search(a,k);

if(p==1)
printf("\nfound\n");
else
printf("\nnot exist\n");

return 0;
}

void input(int *a)
{
int i;
for(i=0;i<N;i++)
scanf("%d",a+i);

}

int search(int *a,int k)
{
int *low,*high,flag=0;
low = a;
high = a+N-1;
    while(flag == 0 && low <= high)
	{
		if(k == *(low + (high - low)/2))
			flag = 1;
		else if(k > *(low + (high - low)/2))
				 low = low + (high - low)/2 + 1;
		else if(k < *(low + (high - low)/2))
				high = low + (high - low)/2 - 1;
	}
return flag;
}