#include<stdio.h>
int main()
{
char x;
int a,b;
x='A';
for(a=0;a<=4;a++)
{
for(b=0;b<(4-a);b++)
{
printf("%c	",x);
x++;
}
printf("\n");
}
getch();
return 0;
}