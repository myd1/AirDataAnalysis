#include<stdio.h>
int main()
{
int a,b,c;
printf("Enter a number: ");
scanf("%d",&a);
for(b=2;b<a;b++)
{
c=a%b;
if(c==0) break;
}
if(c==0)
printf("It is not a prime number \n");
else
printf("It is a prime number \n");
getch();
return 0;
}