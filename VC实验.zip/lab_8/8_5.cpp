#include<stdio.h>
int Fun(int *,int ); 
void output(int *);
int main()
{
	int k;
	int a[10]={1,0,2,0,3,0,4,0,5,0};
output(a);
printf("\n");
k = Fun(a,10);
output(a);
printf("\nthe first zero number is %5d",k);

return 0;
}

int Fun(int *a, int n)
{
	int i, b[10] = {0}, j = 0, first=-1;
	for(i = 0; i < n; ++i)
	{
	if(*(a + i) != 0)
		{
			*(b + j) = *(a + i);
			j++;
		}
		else if(first == -1)
			first = i+1;	
	}
		
	for(i = 0; i < n; ++i)
		*(a + i) = *(b + i);

	return first;
}

void output(int *a)
{
	int i;
	for(i = 0; i < 10; ++i)
		printf("%4d", *(a + i));

}